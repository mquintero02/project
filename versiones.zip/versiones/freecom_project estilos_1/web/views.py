from django.shortcuts import render

# Create your views here.

def index(request):
    return render(request, "pages/index.html")

def presentation(request):
    return render(request, "pages/presentation.html")

def contact(request):
    return render(request, "pages/contact.html")

def projects(request):
    return render(request, "pages/projects.html")

def services(request):
    return render(request, "pages/services.html")